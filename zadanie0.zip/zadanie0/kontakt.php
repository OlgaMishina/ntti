<?php
include 'head.php';
include 'temp/header.php';
include 'temp/nav.php';
include 'temp/database.php';
?>

<section>
    <br>
    <p style="text-align: center"><font color="blue">Главная</font> / <font color="gray"> Контакты</font></p>
    <h3 style="text-align: center">Контакты</h3>
    <hr align="" size="1" color="gray">
</section>

<section>
    <div class="container">
    <div class="col-6"></div>
    <div class="col-6">
    <p class="adres">Адрес</p>
    <p class="adres">Г.Краснодар, ул. Ростовское шоссе, 11/1</p>
    <p class="adres">Телефон</p>
    <p class="adres">8 (861) 212-12-51</p>
    <p class="adres">Время работы</p>
    <p class="adres">Понедельник-Пятница 9:00 - 18:00</p>
    <p class="adres">Суббота: 9:00-16:00</p>
    <p class="adres">Воскресенье: выходной</p>
</div>
</div>

<section class="map">
    <div class="container">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2700.1678764506137!2d40.09210411586671!3d47.40866660962299!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40e24eae27295c59%3A0x7044c21685c65495!2z0J3QvtCy0L7Rh9C10YDQutCw0YHRgdC60LjQuSDRgtC10YXQvdC-0LvQvtCz0LjRh9C10YHQutC40Lkg0YLQtdGF0L3QuNC60YPQvOKAk9C40L3RgtC10YDQvdCw0YI!5e0!3m2!1sru!2sru!4v1652953937945!5m2!1sru!2sru" width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
</section>

</section>

<?php
include 'temp/footer.php';
?>