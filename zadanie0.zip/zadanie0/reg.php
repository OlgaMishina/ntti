<?php

include 'template/head.php';
include 'template/bd_connect.php';

if(!empty($_POST)){
$FIO = $_POST['FIO'];
$Email = $_POST['Email'];
$login = $_POST['login'];
$password = $_POST['password'];



$sql = "insert into user(fio, Email, login, password, role) value ('$FIO', '$Email', '$login', '$password', 'клиент')";
$result=$connection->query($sql);

}

include 'template/nav.php';


?>
<h3>Регистрация</h3>
<form method="POST">
<div class="form-group row">
    <label for="FIO" class="col-sm-2 col-form-label">ФИО</label>
    <div class="col-sm-10">
      <input type="text"  class="form-control" id="FIO" value="" name="FIO">
    </div>
  </div>
  <div class="form-group row">
    <label for="Email" class="col-sm-2 col-form-label">Email</label>
    <div class="col-sm-10">
      <input type="text"  class="form-control" id="Email" value="email@example.com" name = "Email">
    </div>
  </div>
  <div class="form-group row">
    <label for="Login" class="col-sm-2 col-form-label">Логин</label>
    <div class="col-sm-10">
      <input type="text"  class="form-control" id="login" name="login">
    </div>
  </div>
  <div class="form-group row">
    <label for="Password" class="col-sm-2 col-form-label">Пароль</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" id="inputPassword" name = 'password' >  
    </div>
  </div>
  <div class="form-group row">
    <label for="Password" class="col-sm-2 col-form-label">Подтвердите Пароль</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" id="inputPassword" name = 'password2' >  
    </div>
  </div>
<div class = "button">
  <button type="submit" class="btn btn-dark">Регистрация</button>
</div>
</form>


<?php
include 'template/footer.php'
?>