<?php

include 'template/head.php';
include 'template/bd_connect.php';


if(!emptY($_POST['password'] )and !empty($_POST['login']))

$login = $_POST['login'];
$password = $_POST['password'];


$sql = "SELECT * FROM user WHERE login ='$login' AND password = '$password'";
 
$result = $connection->query($sql);
$user = mysqli_fetch_assoc($result);

if(!empty($user)){
session_start();
$_SESSION['id_user'] = $user['id_user']; 
$_SESSION['role'] = $user['role']; 

if ($_SESSION['role'] == 'клиент') {
     header('location:myzakaz.php');
 }
 else if ($_SESSION['role'] == 'менеджер') {
     header('location:vsezakaz.php ');
 }

header("Location: index.php");
  exit;
} else {

  $message = "Неверный логин или пароль";
}

include 'template/nav.php';
?>

<form action="login.php" method="post">
  <div class="form-group row">
    <label for="login" class="col-sm-2 col-form-label">Логин</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" required  name="login" value="">
    </div>
  </div>
  <div class="form-group row">
    <label for="Password" class="col-sm-2 col-form-label">Пароль</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" required  name="password">
    </div>
  </div>
  <div class = "submit">
  <button type="submit" class="btn btn-dark">Авторизироваться</button>
</div>
</form>

<?php
include 'template/footer.php'
?>