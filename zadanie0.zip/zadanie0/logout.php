<?php
session_start();
unset($_SESSION['role']);
unset($_SESSION['login']);
unset($_SESSION['fio']);
header('location: index.php');
?>