<?php
include 'template/head.php';
include 'template/bd_connect.php';
include 'template/nav_user.php';
?>

<button type="submit" class="btn btn-green">Заказать</button>

<h3></h3>    

<form action="" method="post" >
<div class="form-row">
    <div class="form-group col-md-4">
      <label for="date_s">Введите дату с</label>
      <input type="date" class="form-control" id="date_s">
    </div>
    <div class="form-group col-md-4">
      <label for="date_p">Введите дату по</label>
      <input type="date" class="form-control" id="date_p">
    </div>
    <div class="dropdown">
  <div class="form-group col-md-4">
    <label for="dost">Способ доставки </label>
    <select class="form-control" id="spos_dost" name="spos_dost">
      <option>Курьер</option>
      <option>Самовывоз</option>
    </select>
  </div>  
</div>
  </div>
  

  <div class = "form-group">
  <button type="submit" class="btn btn-green">Найти</button>
  <button type="submit" class="btn btn-black">Сбросить</button>
</div>
</form>


<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Товар</th>
      <th scope="col">Дата заказа</th>
      <th scope="col">Количество товара</th>
      <th scope="col">спопсоб доставки</th>
      <th scope="col">цена товара</th>
      <th scope="col">Статус</th>
      <th scope="col">Сумма</th> 
    </tr>
  </thead> 
   <tbody>
<h3>Заказы</h3>
<?php
$sql = "select  *, price * col as value_v from zakaz, tovar where tovar.id_tovar = zakaz.id_tovar";
$result = $connection->query($sql);
foreach($result as $row){


echo
'<tr>
      <td>'.$row['id_tovar'].'</td>
      <td>'.$row['name_tovar'].'</td>
      <td>'.$row['date_zakaz'].'</td>
      <td>'.$row['col'].'</td>
      <td>'.$row['spos_dost'].'</td>
      <td>'.$row['price'].'</td>
      <td>'.$row['status'].'</td>
      <td>'.$row['value_v'].'</td>
    </tr>';
}
?>
</tbody>
</table>


<?php
include 'template/footer.php';
?>