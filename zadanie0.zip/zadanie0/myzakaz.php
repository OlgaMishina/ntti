<?php
session_start();
include 'head.php';
include 'temp/header.php';
include 'temp/navclient.php';
include 'temp/database.php';
$id_user = $_SESSION['id_user'];
$fio=$_SESSION['fio'];
?>

<div class="container">
	<div class="row">
		<table class="table">
			<tr>   <th>Название</th>
            <th>Дата заказа</th>
				<th>Адрес</th>
				<th>Количество</th>
                <th>Цена</th>
                <th>Способ доставки</th>
			</tr>
            <?php
$sql = "SELECT * FROM zakaz , tovar WHERE tovar.id_tovar=zakaz.id_tovar and id_user =$id_user";
$result= $mysqli->query($sql);
foreach($result as $row) {
	echo'<tr> <td>'.$row['name_tovar'].'</td>
		  <td>'.$row['data_zakaza'].'</td>
	  <td>'.$row['adres'].'</td> 
       <td>'.$row['col_vo'].'</td>
		  <td>'.$row['price'].'</td>
          <td>'.$row['sposob'].'</td>
          </tr>';
}
?>
		</table>
	</div>	
</div>

<?php include 'temp/footer.php';?>