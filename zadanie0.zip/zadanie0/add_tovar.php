<?php

include 'template/head.php';
include 'template/bd_connect.php';
include 'template/nav_menger.php';

?>
<h3>Добавление товара</h3>

<form enctype="multipart/form-data" method="POST">
<div class="form-group row">
    <label for="name_tovar" class="col-sm-2 col-form-label">Наименование товара</label>
    <div class="col-sm-10">
      <input type="text"  class="form-control" id="name_tovar" value="" name="name_tovar">
    </div>
  </div>
  <div class="form-group row">
    <label for="razmer" class="col-sm-2 col-form-label">Размер</label>
    <div class="col-sm-10">
      <input type="text"  class="form-control" id="razmer"  name = "razmer">
    </div>
  </div>
  <div class="form-group row">
    <label for="massa" class="col-sm-2 col-form-label">Масса</label>
    <div class="col-sm-10">
      <input type="text"  class="form-control" id="massa" name="massa">
    </div>
  </div>
  <div class="form-group row">
    <label for="price" class="col-sm-2 col-form-label">Цена</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="price" name = 'price' >  
    </div>
  </div>
  <div class="form-group row">
    <label for="userfile" class="col-sm-2 col-form-label"></label>
    <div class="col-sm-10">
        <input type="hidden" name="MAX_FILE_SIZE" value="300000000" />
      <input type="file" class="form-control" id="userfile" name = 'userfile' >  
    </div>
  </div>
<div>
  <button type="submit" class="btn btn-dark">Добавление</button>
</div>

<?php
if(!empty($_POST)){
$name_tovar = $_POST['name_tovar'];
$razmer = $_POST['razmer'];
$massa = $_POST['massa'];
$price = $_POST['price'];
$id_tovar = $_GET ['id_tovar'];


$sql = "insert into tovar(name_tovar, razmer, massa, price  ) value ('$name_tovar', $razmer, $massa, $price )";
$result = $connection->query($sql);

$id = $connection->insert_id;

$dir = 'image/';

$file_bd = $id.'_'. basename($_FILES['userfile']['name']);
$file = $dir.$file_bd;
var_dump($file);


echo '<pre>';
if (move_uploaded_file($_FILES['userfile']['tmp_name'], $file)) 
{
  echo "Файл  успешно загружен.\n";

  $sql = "update tovar set img ='$file_bd' where id_tovar = $id";
  var_dump($sql);
  $result = $connection->query($sql);
  } else {
  echo "Возможная атака с помощью файловой загрузки!\n";
  }
    echo 'Некоторая отладочная информация:';
  print_r($_FILES);
    print "</pre>";
}
?>
