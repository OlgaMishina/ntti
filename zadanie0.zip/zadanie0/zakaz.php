<?php
session_start();
$id_user = $_SESSION['id_user'];
include 'head.php';
include 'temp/header.php';
include 'temp/navmenedg.php';
include 'temp/database.php';
?>

<?php include 'temp/footer.php';?>