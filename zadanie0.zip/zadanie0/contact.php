<?php
include 'template/head.php';
include 'template/bd_connect.php';
include 'template/nav.php';
?>

<h2>Контакты</h2>