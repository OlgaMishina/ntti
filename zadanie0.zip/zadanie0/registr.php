<?php
include 'head.php';
include 'temp/header.php';
include 'temp/nav.php';
include 'temp/database.php';
?>

    <div class="container">
<div class="row">
<div class="col-4"></div>
<div class="col-4">
    <div class="users">
        <div class="card">
            <div class="card-body">
                <form method="POST" action="adduser.php" role="form" class="form-inline">
                <h2>Регистрация</h2>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Роль</label>
                    <select class="form-select" name="role" aria-label="Default select example">
                        <option value="Клиент">Клиент</option>
                        <option value="Менеджер">Менеджер</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Ваше ФИО<font color="red">*</font></label>
                    <input type="text" class="form-control" id="exampleInputEmail1"  required  name="fio" aria-describedby="emailHelp" placeholder="">
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Эл.почта<font color="red">*</font></label>
                    <input type="email" class="form-control" id="exampleInputemail"  required name="email"  placeholder="">
                </div>
                
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Логин<font color="red">*</font></label>
                    <input type="text" class="form-control" id="login" name="login"  required  placeholder="">
                </div>
                <div id="mass"></div>        
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Пароль<font color="red">*</font></label>
                    <input type="password" class="form-control"name="password" id="pass"  required  placeholder="">
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Подвердите пароль<font color="red">*</font></label>
                    <input type="password" class="form-control" id="pas" name="pas" placeholder=""  required >
                </div>
            

                <button type="submit" class="btn btn-primary" href="avtoriz.php">Зарегистрироваться</button>
                    <div class="text1">
                        <a>Уже есть аккаунт?</a>
                        <a href="avtoriz.php">Войти</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<div class="col-4"></div>
</div>
</div>
</section>

      <br>
      <br>

<?php include 'temp/footer.php';?>