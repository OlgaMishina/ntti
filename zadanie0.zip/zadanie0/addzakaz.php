<?php
session_start();
    if($_SESSION['role']!="Клиент"){
    header("location: avtoriz.php");
        }
include 'head.php';
include 'temp/header.php';
include 'temp/navclient.php';
include 'temp/database.php';
?>
<?php
if  (!empty($_POST))
 {$col_vo = $_POST['col_vo'];
$data = date("d.m.Y");
$adres = $_POST ['adres'];
$sposob = $_POST['sposob'];
$id_tovar = $_GET['id_tovar'];
$id_user = $_SESSION['id_user'];
var_dump($id_user);
$sql ="insert into zakaz(col_vo,data_zakaza, adres, sposob, id_tovar,id_user) values ('$col_vo','$data','$adres','$sposob','$id_tovar','$id_user')";
$result = $mysqli->query($sql); 
header('location: myzakaz.php');
}
?>
<div class="container">
	<div class="row">
		<div class="col">
<form  method="POST"  role="form" class="form-inline"  style="border: 1px solid gray;
    padding: 10px;">
<div class="form-group mb-2 col-4">
<label for="example1" class="form-label"> Введите количество товара:</label>
<input type="text" class="form-control" style= "border-color: #696969; width: 350px; height: 35px;" name="col_vo" placeholder="" requered>
</div>
<div class="form-group mb-2 col-4">
<label for="example1" class="form-label"> Введите ваш адрес:</label>
<input type="text" class="form-control"style= "border-color: #696969; width: 350px; height: 70px;"  name="adres" placeholder="" requered>
</div>
            <div class=" mb-2 col-4">
                <label for="data1"> Дата заказа:</label><br>
                <input type="date" id="data1">
        </div>
		
		<div class=" mb-2 col-4">
        <label for="s"> Способ доставки:</label>
        <select class="form-select" id="sposob" name="sposob" aria-label="Default select example">
            <option value="Курьер">Курьер</option>
            <option value="Самовывоз">Самовывоз</option>
          </select>
        </div>

<div class="form-group mb-2 col-4">
<button type="submit" class="btn btn-warning">Оформить заказ</button>
</div>
</form>	
	</div>
	</div>
</div>

<?php include 'temp/footer.php';  ?>