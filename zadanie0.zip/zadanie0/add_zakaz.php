<?php
include 'template/bd_connect.php';
if(!empty($_POST)){
    $col = $_POST['col'];
    $date_zakaz = $_POST['date_zakaz'];
    $adress_dost = $_POST['adress_dost'];
    $spos_dost = $_POST['spos_dost'];
    $id_tovar = $_POST['id_tovar'];
    session_start();
    $id_user = $_SESSION['id_user'];
   

    $sql = "insert into zakaz(id_user, id_tovar, spos_dost, adress_dost, date_zakaz, col) value ($id_user, $id_tovar, '$spos_dost', '$adress_dost', '$date_zakaz', $col)";
    $result = $connection->query($sql);
   
    if ($_SESSION['role'] == 'клиент') {
        header('location:myzakaz.php');}

}

?>
