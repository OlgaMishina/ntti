<!DOCTYPE html>
<html lang="en">
<head>
      <!-- SITE TITTLE -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Главная</title>
       <!-- FAVICON -->
      <link href="images/favicon.png" rel="shortcut icon">
      <!-- PLUGINS CSS STYLE -->
      <!-- <link href="plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet"> -->
            <script src="js/jquery-3.6.0.js"></script><!-- Bootstrap -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- Font Awesome -->
      <!-- <link href="css/style.css" rel="stylesheet"> -->
      <script src="js/bootstrap.js"></script>

      <script src="js/ajax.js"></script>
      <script type="text/javascript" src="js/password.js"></script>
</head>
