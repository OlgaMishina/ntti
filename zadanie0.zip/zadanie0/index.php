<?php
$menu = 'template/nav.php';
session_start();
if ($_SESSION['role'] == 'клиент') {
     $menu = 'template/nav_user.php';
 }
 else if ($_SESSION['role'] == 'менеджер') {
  $menu = 'template/nav_menger.php';
 }


include 'template/head.php';
include 'template/bd_connect.php';
include $menu;
?>
<body>
<section class="hero-area bg-1 text-center overly">
  <!-- Container Start -->
  <div class="container">
      <div class="row">
          <div class="col-md-12">
              <!-- Header Contetnt -->
              <div class="content-block">
                  <h1>Почему с нами выгодно работать?</h1>
                  <img src ="image/гарантия.png" width='200'>
                  <img src ="image/большойвыбор.png" width='200'>
                  <img src ="image/опыт работы.png" width='200'>
                  <img src ="image/проверенный кирпич.png"width='200' >
              </div>
          </div>
      </div>
  </div>  <!-- Container End -->
</section>

<section class=" section">

<div class = "container">
  <div class = "row">
    <div class = "col-2"></div>
    <div class = "col-8">
  <!-- Container Start -->
  <div class="row row-cols-1 row-cols-md-4">
    <?php
    $sql = "select * from tovar";
    $result = $connection->query($sql);
    foreach($result as $row){
    
 echo'<div class="col mb-4">
    <div class="card">
      <img src="image/'.$row['img'].'" class="card-img-top" >
      <div class = "card-body">
        <h5 class = "card-title">'.$row['name_tovar'].'
        <p class = "card-text">'.$row['price'].'</p>
        <button type="button" class="btn btn-danger" 
data-bs-toggle="modal" data-bs-target="#myModal" 
data-id_tovar="'.$row['id_tovar'].'" data-name_tovar="' .$row['name_tovar'].'" >Купить</button>
      </div>
    </div>
  </div>';
};
?>
</div>
<div class = "col-2"></div>
</div>
</div>
</div>
</section>
<!--  модальноe окнo -->
<div id="myModal" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Заголовок модального окна -->
      <div class="modal-header">
        <h4 class="modal-title">Заказ товара</h4>
      </div>
      <!-- Основное содержимое модального окна -->
      <div class="modal-body">  
       <div class="form-group mb-2  col-12">
         <form  method="post" action="add_zakaz.php" role="form" class="form-inline">

         <div class="form-group">
    <label for="col">Количество товара</label>
    <input type="text" class="form-control" id="col" name ='col' placeholder="Введите количество товара">
    <input type="hidden" class="form-control"  name="id_tovar" id="id_tovar">
  </div>
  <div class="form-group">
    <label for="date">Дата заказа</label>
    <input type="date" class="form-control" id="date_zakaz" name="date_zakaz" >
  </div>
  <div class="form-group">
    <label for="adress">Адрес доставки</label>
    <input type="text" class="form-control" id="adress_dost" name="adress_dost" placeholder="Введите адрес доставки">
  </div>
  <div class="form-group">
    <label for="dost">Способ доставки </label>
    <select class="form-control" id="spos_dost" name="spos_dost">
      <option>Курьер</option>
      <option>Самовывоз</option>
    </select>
  </div>           
            </div>
          </div>
<!-- Футер модального окна -->
 <div class="modal-footer">
 <div class="col-sm-10">


  
  <div class="form-group">
    <button type="button" class="close" data-dismiss="modal"  aria-hidden="true"> Закрыть</button>
    <button type="submit" name="submit" class="btn btn-primary"> Сохранить </button>
</div>
</form>
 </div>
</div>
</div>
</div> 


<?php

include 'template/footer.php';
?>

<!-- Вызов модального окна -->
<script>
$(document).ready(function(){
  $('#myModal').on('show.bs.modal', function (event) {
// кнопка, которая вызывает модаль
 var button = $(event.relatedTarget) 
// получим  data-id_tovar атрибут
  var id_tovar = button.data('id_tovar') 
// получим  data-name_tovar атрибут
  var name_tovar = button.data('name_tovar');
   // Здесь изменяем содержимое модали
  var modal = $(this);
 modal.find('.modal-title').text('Заказать '+name_tovar+' '+id_tovar);
 modal.find('.modal-body #id_tovar').val(id_tovar);
})
});
</script>

