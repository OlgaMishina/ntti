<?php
session_start();

include 'head.php';
include 'temp/header.php';
include 'temp/nav.php';
include 'temp/database.php';
?>
<!--==========================================
=           Основной контент страницы           =
===========================================-->
<section class="section" style="background-color: #2578;    height: 450px;">
    <!-- Container Start -->
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title">
                    <h3 style="text-align: center;"> Почему с нами выгодно работать?</h3>
                    <div class="row row-cols-1 row-cols-md-4 g-4">
  <div class="col">
    <div class="card">
      <img src="images/гарантия.png" class="card-img-top" alt="...">
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="images/большойвыбор.png" class="card-img-top" alt="...">

    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="images/опыт работы.png" class="card-img-top" alt="...">
    
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="images/проверенный кирпич.png" class="card-img-top" alt="...">
    </div>
  </div>
</div> 
       
                </div>
            </div>
        </div>
    </div>
  </section>
  <section class="sect">
        <div class="container">
        <div class="row">
            <div class="col-lg-12" >
            <div class="row row-cols-1 row-cols-md-4 g-4">
            <?php
            $sql ="SELECT * FROM tovar";
            $result= $mysqli->query($sql);
            foreach($result as $row) {
       
              echo' <div class="col">
               <div class="card">
              <img src="images/'.$row['img'].'" class="card-img-top" alt="...">
              <div class="card-body">
              <h5 class="card-title">Цена за шт:'.$row['price'].'</h5>
                <p class="card-text">'.$row['name_tovar'].'</p>
                <a href="addzakaz.php?id_tovar='.$row['id_tovar'].'" class="btn btn-dark">Сделать заказ</a>
              </div>
            </div>
            </div>';
              }
            ?>
            </div>
            </div>
        </div>
      
    </div><!-- Container End -->
</section>
<?php include 'temp/footer.php';?>