<?php
include 'template/head.php';
include 'template/bd_connect.php';
include 'template/nav_menger.php';

?>

<h3>Отчет о выполнений заказа</h3>
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Товар</th>
      <th scope="col">Дата заказа</th>
      <th scope="col">Менеджер
      <th scope="col">Исполнитель
      <th scope="col">Количество товара</th>
      <th scope="col">спопсоб доставки</th>
      <th scope="col">цена товара</th>
      <th scope="col">Статус</th>
      <th scope="col">Сумма</th> 
    </tr>
  </thead> 
   <tbody>
<h3>Заказы</h3>
<?php
$sql = "select * from ";
$result = $connection->query($sql);
foreach($result as $row){


echo
'<tr>
      <td>'.$row['id_tovar'].'</td>
      <td>'.$row['name_tovar'].'</td>
      <td>'.$row['date_zakaz'].'</td>
      <td>'.$row['col'].'</td>
      <td>'.$row['spos_dost'].'</td>
      <td>'.$row['price'].'</td>
      <td>'.$row['status'].'</td>
      <td>'.$row[''].'</td>
    </tr>';
}
?>
</tbody>
</table>
}
?>
</tbody>
</table>