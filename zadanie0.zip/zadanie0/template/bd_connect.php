<?php
$connection = new mysqli("localhost", "root", "","rostovkurpih");

?>