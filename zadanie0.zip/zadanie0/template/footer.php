<footer class="footer-bottom">
  <!-- Container Start -->
  <div class="container">
    <div class="row">
      <div class="col-sm-6 col-12">
        <!-- Copyright -->
        <div class="copyright">
          <p>Фамилия разработчика © 2020 Все права защищены </p>
        </div>
      </div>
    </div>
  </div>
</footer>
</body>
</html>
