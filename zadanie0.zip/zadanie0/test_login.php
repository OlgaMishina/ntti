<?php
include 'temp/database.php';
$login = $_POST['login'];
$sql = "select login from user where login = '$login'";
$result = $mysqli->query($sql);
if ($result->num_rows >0){
    echo '<p >Такой логин уже существует!</p>';
}
else{
    echo '';
}

?>