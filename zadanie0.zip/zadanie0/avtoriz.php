<?php
include 'head.php';
include 'temp/header.php';
include 'temp/nav.php';
include 'temp/database.php';
if(!empty($_POST)) {
    $login = $_POST['login'];
    $password = $_POST['password'];
    //формируем и отсылаем SQL запрос:
    $sql = "SELECT * FROM user WHERE login='$login' AND password='$password'";
    //выполнить запрос 

    $result = $mysqli->query($sql);
    $user = mysqli_fetch_assoc($result);
    if(!empty($user)){
        session_start();
        $_SESSION['login']=$user['login'];
        $_SESSION['fio']=$user['fio'];
        $_SESSION['id_user']=$user['id_user'];
        $_SESSION['role']=$user['role'];
        //Пользователь прошел aвторизацию
        header("location: myzakaz.php");
        exit;
    }else{
        $message = 'Неверный логин или пароль';
    }
}
?>
    
    <section style="text-align:center;">
        <br>
        <p><font color="blue">Главная</font> / <font color="gray"> Авторизация</font></p>
        <h3 class="avt">Авторизация</h3>
        <hr>
    </section>
    <div class="row">
        <div class="col-4"></div>
            <div class="col-4"> 
                <h6 style="text-align:center;">Войдите в свой аккаунт</h6>
                    <h6 style="text-align:center;">Добро пожаловать! Если вы не зарегистрированы, пройдите <a href="registr.php">регистрацию</a> на сайте.</h6>
                <form method="POST"  role="form" class="form-inline" style="border: 1px solid gray;
    padding: 10px;">  
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Логин <font color="red">*</font></label>
              <input type="text" class="form-control" id="exampleInputEmail1" name="login" placeholder="Введите логин" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">Пароль <font color="red">*</font></label>
              <input type="password" class="form-control" id="exampleInputPassword1"  name="password"placeholder="Введите пароль">
            </div>
            <div class="button"><button type="submit" class="btn btn-warning"><font color="white">Войти</font></button></div>
        </form>
        </div>
        <div class="col-4"></div>
    </div>
      <br>
      <br>
<?php include 'temp/footer.php';?>