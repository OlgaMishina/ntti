<?php
	include 'temp/database.php'; 
	if (!empty($_POST)){
$fio = $_POST['fio'];
$email = $_POST['email'];
$login = $_POST['login'];
$password = $_POST['password'];
$role = $_POST['role'];
$sql="insert into user(fio,email,login,password,role) values ('$fio','$email','$login','$password','$role')";
//Выполнить запрос
$result= $mysqli->query($sql);

header("location: avtoriz.php");
exit;
	}
	?>