<!--==========================================
=         Заголовок главной страницы страницы           =
===========================================-->
<header class="header">
<section class="hero-area bg-1 text-center overly">

    <!-- Container Start -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- Header Contetnt -->

            </div>
        </div>
    </div>
 <!-- Container End -->
</section>
</header> 