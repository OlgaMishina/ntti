<?php
$mysqli = new mysqli ("localhost", "root", "","zadanie_0");
$mysqli->set_charset("utf8");
?>
